# Secrets do be excluded from Git and others.

# Sign cookies for sessions
nogit_secret_key = 'PlaceYourOwnHere!' 

# Set these values from the Linkedin app you created
NOGIT_CONSUMER_KEY = 'PlaceYourOwnHere!'
NOGIT_CONSUMER_SECRET = 'PlaceYourOwnHere!'
